from django.shortcuts import render
from .models import Reservation
from .serializers import ReservationSerializers
from rest_framework import generics


def index(request):
    if request.method == "POST":
        name            = request.POST['name']
        room_number     = request.POST['room_number']
        date_check_in   = request.POST['start_date']
        date_check_out  = request.POST['end_date']
        ins = Reservation(name=name, room_number=room_number , date_check_in=date_check_in, date_check_out=date_check_out)
        ins.save()
    return render(request,'index.html')

class rooms_overview(generics.ListAPIView):
    queryset         = Reservation.objects.all()
    serializer_class = ReservationSerializers
