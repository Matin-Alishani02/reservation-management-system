from django.db import models

class Room (models.Model):
    number   = models.IntegerField(unique=True)
    capacity = models.IntegerField()
    def __str__(self):
        return str(self.number)

class Reservation (models.Model):
    name           = models.CharField(max_length=50)
    room_number    = models.IntegerField()
    date_check_in  = models.DateField()
    date_check_out = models.DateField()
    def __str__(self):
        return self.name


