from django.contrib import admin
from .models import Room ,Reservation

@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display  =         ('number',)

@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display  =         ('name','room_number','date_check_in' ,"date_check_out")
